<?php

function custom_post_type_bannerheader() {
    $labels = array(
    'name'                  => 'banner do header', 'Post Type General Name',
    'singular_name'         => 'banner do header', 'Post Type Singular Name',
    'menu_name'             => 'banner do header',
    'name_admin_bar'        => 'bannerheader',
    'archives'              => 'Arquivos de bannerheader',
    'attributes'            => 'Atributos do bannerheader',
    'parent_item_colon'     => 'bannerheader pai',
    'all_items'             => 'Todos os banner do header',
    'add_new_item'          => 'Adicionar novo banner do header',
    'add_new'               => 'Adicionar banner do header',
    'new_item'              => 'Novo bannerheader',
    'edit_item'             => 'Editar banner do header',
    'update_item'           => 'Atualizar banner do header',
    'view_item'             => 'Visualizar banner do header',
    'view_items'            => 'Visualizar banner do header',
    'search_items'          => 'Pesquisar banner do header',
    'not_found'             => 'Nada foi encontrado',
    'not_found_in_trash'    => 'Nenhuma promoção foi encontrada na lixeira',
    'featured_image'        => 'Imagem destacada',
    'set_featured_image'    => 'Selecionar como imagem destacada',
    'remove_featured_image' => 'Remover imagem destacada',
    'use_featured_image'    => 'Use como imagem destacada',
    'insert_into_item'      => 'Inserir no bannerheader',
    'uploaded_to_this_item' => 'Carregados no bannerheader',
    'items_list'            => 'Lista de banner do header',
    'items_list_navigation' => 'Lista de navegação',
    'filter_items_list'     => 'Filtrar lista',
    );
    $args = array(
    'label'                 => 'banner do header',
    'description'           => 'banner do header (rodapé)',
    'labels'                => $labels,
    'supports'              => array( 'title', 'editor', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'post-formats' ),
    'taxonomies'            => array('bannerheader_categories'),
    'hierarchical'          => false,
    'public'                => true,
    'show_ui'               => true,
    'show_in_menu'          => true,
    'menu_position'         => 5,
    'menu_icon'             => 'dashicons-pressthis',
    'show_in_admin_bar'     => true,
    'show_in_nav_menus'     => true,
    'can_export'            => true,
    'has_archive'           => true,
    'exclude_from_search'   => false,
    'publicly_queryable'    => true,
    'capability_type'       => 'page',
    );
    register_post_type( 'bannerheader', $args );
  }
  add_action( 'init', 'custom_post_type_bannerheader', 0 );
  
  // Register Custom Post Type bannerheader
  function bannerheader_taxonomy() {  
    register_taxonomy(  
        'bannerheader_categories',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'bannerheader',        //post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Categoria do banner do header',  //Display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'bannerheader', // This controls the base slug that will display before each term
                'with_front' => false // Don't display the category base before 
            )
        )  
    );  
  }  
  add_action( 'init', 'bannerheader_taxonomy');

  
function custom_post_type_bannerfooter() {
    $labels = array(
    'name'                  => 'banner do footer', 'Post Type General Name',
    'singular_name'         => 'banner do footer', 'Post Type Singular Name',
    'menu_name'             => 'banner do footer',
    'name_admin_bar'        => 'bannerfooter',
    'archives'              => 'Arquivos de bannerfooter',
    'attributes'            => 'Atributos do bannerfooter',
    'parent_item_colon'     => 'bannerfooter pai',
    'all_items'             => 'Todos os banner do footer',
    'add_new_item'          => 'Adicionar novo banner do footer',
    'add_new'               => 'Adicionar banner do footer',
    'new_item'              => 'Novo bannerfooter',
    'edit_item'             => 'Editar banner do footer',
    'update_item'           => 'Atualizar banner do footer',
    'view_item'             => 'Visualizar banner do footer',
    'view_items'            => 'Visualizar banner do footer',
    'search_items'          => 'Pesquisar banner do footer',
    'not_found'             => 'Nada foi encontrado',
    'not_found_in_trash'    => 'Nenhuma promoção foi encontrada na lixeira',
    'featured_image'        => 'Imagem destacada',
    'set_featured_image'    => 'Selecionar como imagem destacada',
    'remove_featured_image' => 'Remover imagem destacada',
    'use_featured_image'    => 'Use como imagem destacada',
    'insert_into_item'      => 'Inserir no bannerfooter',
    'uploaded_to_this_item' => 'Carregados no bannerfooter',
    'items_list'            => 'Lista de banner do footer',
    'items_list_navigation' => 'Lista de navegação',
    'filter_items_list'     => 'Filtrar lista',
    );
    $args = array(
    'label'                 => 'banner do footer',
    'description'           => 'banner do footer (rodapé)',
    'labels'                => $labels,
    'supports'              => array( 'title', 'editor', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'post-formats' ),
    'taxonomies'            => array('bannerfooter_categories'),
    'hierarchical'          => false,
    'public'                => true,
    'show_ui'               => true,
    'show_in_menu'          => true,
    'menu_position'         => 6,
    'menu_icon'             => 'dashicons-pressthis',
    'show_in_admin_bar'     => true,
    'show_in_nav_menus'     => true,
    'can_export'            => true,
    'has_archive'           => true,
    'exclude_from_search'   => false,
    'publicly_queryable'    => true,
    'capability_type'       => 'page',
    );
    register_post_type( 'bannerfooter', $args );
  }
  add_action( 'init', 'custom_post_type_bannerfooter', 0 );
  
  // Register Custom Post Type bannerfooter
  function bannerfooter_taxonomy() {  
    register_taxonomy(  
        'bannerfooter_categories',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'bannerfooter',        //post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Categoria do banner do footer',  //Display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'bannerfooter', // This controls the base slug that will display before each term
                'with_front' => false // Don't display the category base before 
            )
        )  
    );  
  }  
  add_action( 'init', 'bannerfooter_taxonomy');
  

  
