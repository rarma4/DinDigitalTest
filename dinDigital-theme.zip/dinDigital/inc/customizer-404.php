<?php 

function nofound_customize_register($wp_customize) {

    //Rodapé
    $wp_customize -> add_section('404', array(
        'title' => __('404', 'rarma4'),
        'description' => sprintf(__('Opções para o 404','rarma4')),
        'priority' => 20
    ));

    $wp_customize -> add_setting('404_title', array(
        'default' => _x('Página não encontrada', 'rarma4'),
        'type' => 'theme_mod'
    ));

    $wp_customize -> add_control('404_title',array(
        'label' => __('Título do 404', 'rarma4'),
        'section' => '404',
        'priority' => 1
    ));

    $wp_customize -> add_setting('404_text', array(
        'default' => _x('O caminho para o conteúdo que você deseja acessar está errado ou a página pode ter sido excluída.', 'rarma4'),
        'type' => 'theme_mod'
    ));

    $wp_customize -> add_control('404_text',array(
        'label' => __('Texto do 404', 'rarma4'),
        'section' => '404',
        'priority' => 3
    ));

    $wp_customize->add_setting('img404');
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'img404', array(
        'label' => 'Logo 404',
        'section' => '404', 
        'settings' => 'img404',
        'priority' => 8 
    )));

    
}

add_action('customize_register','nofound_customize_register');

