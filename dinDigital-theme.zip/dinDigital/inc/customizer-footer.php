<?php 

function din_customize_register($wp_customize) {

    //Rodapé
    $wp_customize -> add_section('footer', array(
        'title' => __('Rodapé', 'din'),
        'description' => sprintf(__('Opções para o rodapé','din')),
        'priority' => 20
    ));

    $wp_customize -> add_setting('footer_title', array(
        'default' => _x('Padrão tema Din', 'din'),
        'type' => 'theme_mod'
    ));

    $wp_customize -> add_control('footer_title',array(
        'label' => __('Título do rodapé', 'din'),
        'section' => 'footer',
        'priority' => 1
    ));

    $wp_customize -> add_setting('footer_text', array(
        'default' => _x('Copywright 2020 Bella Onojie.com', 'din'),
        'type' => 'theme_mod'
    ));

    $wp_customize -> add_control('footer_text',array(
        'label' => __('Texto do rodapé', 'din'),
        'section' => 'footer',
        'priority' => 2
    ));
}

add_action('customize_register','din_customize_register');