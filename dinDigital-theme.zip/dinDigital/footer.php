

<div class="container mt-5">
  <div class="row text-center">
      <div class="col-lg-4 col-sm-12 logoFooter">
        <a href="<?php bloginfo('url'); ?>">
            <?php
            
              $custom_logo_id = get_theme_mod( 'custom_logo' );
              $logo = wp_get_attachment_image_src( $custom_logo_id, 'full' );

              if ( has_custom_logo() ) {

                echo '<img src="' . esc_url( $logo[0] ) . '" class="img-fluid mb-5">';

              } else {
                echo '<h1>' . get_bloginfo('name') . '</h1>';
                echo '<p class="lead">' . get_bloginfo('description') . '</p>';
              }

            ?>
        </a>
      </div>
      <div class="col-lg-4 col-sm-12 mt-5">
      <a href=""><i class="fab fa-twitter"></i></a>
      <a href=""><i class="fab fa-facebook-square"></i></a>
      <a href=""><i class="fab fa-instagram"></i></a>
         
      </div>
      <div class="col-lg-4 col-sm-12 "> 
         <p class="copyright mt-5"><?php echo get_theme_mod('footer_text', 'Copywright 2020 Bella Onojie.com'); ?></p>
      </div>
  </div>
</div>

    <?php wp_footer(); ?>
    <script src="<?php bloginfo('template_url') ?>/js/jquery.js"></script>
    <script src="<?php bloginfo('template_url') ?>/js/popper.js"></script>
    <script src="<?php bloginfo('template_url') ?>/js/bootstrap.js"></script>

  </body>
</html>

<?php

