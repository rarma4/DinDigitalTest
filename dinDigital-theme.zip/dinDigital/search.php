<!-- pagina de buscas -->
<?php get_header(); ?>

  <div class="container">

    <div class="row mt-4">

      <div class="col-md-12 col-sm-12">

        <?php 
        // Se houver resultados exibe o conteúdo, se não exibe um formuládio de buscas
        if (is_search()) :
          $total_results = $wp_query->found_posts;

          echo "<h3 class='mb-3'>" . sprintf( __('%s resultado(s) para "%s"','Din Digital'), $total_results, get_search_query()) . "</h3><hr>";

        endif;
        ?>

        <?php if(have_posts()) : while(have_posts()) : the_post(); ?>

        <div class="row">
          <div class="col-lg-6 col-sm-12 ">
              <div>
                  <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                  <h4><a href="<?php the_permalink(); ?>"><?php the_excerpt(); ?></a></h4>
              </div>
          </div>
          <div class="col-lg-6 col-sm-12">
              <a href="<?php the_permalink(); ?>">
                  <?php the_post_thumbnail('post-thumbnail', array('class' => 'thumb')); ?>
              </a>
          </div>
        </div>

          <?php endwhile; ?>

        <?php else : 
        
        echo "<p>Sua busca não econtrou resultados. Use o formulário abaixo para refazer a busca.</p>";
        get_search_form();  

        endif; ?>

        <div class="blog-pagination mb-5">
          <?php next_posts_link( 'Mais antigos' ); ?> <?php previous_posts_link( 'Mais novos' ); ?>
        </div>

      </div>

    </div>

  </div>

<?php get_footer(); ?>