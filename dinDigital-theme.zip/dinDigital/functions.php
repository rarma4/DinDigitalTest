<?php

// Chamar a tag Title e adicionar os formatos de posts
function din_theme_support() {

    // Chamar a tag Title
    add_theme_support('title-tag');

    // Adicionar os formatos de posts
    //add_theme_support('post-formats', array('aside', 'image'));

    // Adicionar o logotipo
    add_theme_support( 'custom-logo' );
}
add_action('after_setup_theme', 'din_theme_support');

add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 1280, 720, true );


// Previnir o erro na tag Title em versões antigas
if (!function_exists('_wp_render_title_tag')) {
    function din_render_title() {
        ?>
        <title><?php wp_title('|', true, 'right'); ?></title>
        <?php
    }
    add_action('wp_head', 'din_render_title');
}

// Registra o Custom Navigation Walker (https://github.com/wp-bootstrap/wp-bootstrap-navwalker)
require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

register_nav_menus( array(
    'principal' => __('Menu principal', 'din'),
    'secundario' => __('Menu secundario', 'din')
));

// Definir o tamanho o resumo
add_filter( 'excerpt_length', function($length) {
    return 50;
} );

// registra widget da barra lateral
register_sidebar(
    array(
        'name' => 'Barra lateral',
        'id' => 'sidebar',
        'before_widget' => '<div class="card mb-4">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="card-header">',
        'after_title' => '</h5><div class="card-body">',
));

// registra widget do campo de busca
register_sidebar(
    array(
        'name' => 'Busca',
        'id' => 'busca',
        'before_widget' => '<div class="blog-search">',
        'after_widget' => '</div>',
        'before_title' => '<h5>',
        'after_title' => '</h5>',
));

// Ativar o fomrulário para respostas nos comentários
function theme_queue_js() {
    if ( (!is_admin()) && is_singular() && comments_open() && get_option('thread_comments') ) wp_enqueue_script('comment-reply');
}
add_action('wp_print_scripts', 'theme_queue_js');

  // Incluir as funções de personalização, como "extensao do functions"
  require get_template_directory(). '/inc/customizer-post-type.php';
  require get_template_directory(). '/inc/customizer-form-coments.php';
  require get_template_directory(). '/inc/customizer-footer.php';
  require get_template_directory(). '/inc/customizer-404.php';