<!-- onde sera exibido os posts -->
<?php get_header(); ?>

<?php if(have_posts()) : while(have_posts()) : the_post(); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-6 col-sm-12 d-flex align-items-center">
            <div>
                <h3><?php echo get_post_meta($post->ID, 'subtitle', true); ?></h3>
                <h2><?php the_title(); ?></h2>
                <h4><?php the_content(); ?></h4>
                <hr>
                <?php comments_template(); ?>
            </div>
        </div>
        <div class="col-lg-6 col-sm-12">
                <?php the_post_thumbnail('post-thumbnail', array('class' => 'img-fluid rounded')); ?>
        </div>
    </div>

    <?php endwhile; else: get_404_template();?>
    <?php endif; ?>
</div>


<?php get_footer(); ?>