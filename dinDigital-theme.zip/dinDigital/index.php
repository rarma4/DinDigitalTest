<!-- onde sera exibido os posts -->
<?php get_header(); ?>


<div class="container">

    <?php $cont = 1; if(have_posts()) : while(have_posts()) : the_post(); ?>

        <div class="row <?php if ( $cont % 2==0)  echo"flex-row-reverse";?>">
            <div class="col-lg-12 col-sm-12 mt-5">
                <div>
                    <h2><?php the_title(); ?></a></h2>
                    <h4><?php the_content(); ?></a></h4>
                </div>
            </div>
            <!-- <div class="col-lg-12 col-sm-12">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('post-thumbnail', array('class' => 'img-fluid text-center')); ?>
                </a>
            </div> -->
        </div>

    <?php $cont ++; endwhile; else: get_404_template();?>
    <?php endif; ?>
        <div class="blog-pagination mb-5">
            <?php next_posts_link( 'Mais antigos' ); ?> <?php previous_posts_link( 'Mais novos' ); ?>

        </div>
</div>


<?php get_footer(); ?>