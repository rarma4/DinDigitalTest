<!-- onde sera exibido os posts -->
<?php get_header(); ?>

<div class="container-fluid p-0 mt-4">
  <div class="row">
    <div class="col ">
      <div id="carouselExampleControlsHeader" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner ">

        <?php
            $postType = 'bannerheader';
            $args = array(
                'post_type'   => $postType,
                'posts_per_page'=> 9,
                'order' => 'ASC',
                // 'taxonomy'=>'category'
                
            );
            $myquery = new WP_Query( $args );
            ?>

            <?php $conter = 1; if($myquery->have_posts()) : while($myquery->have_posts()) : $myquery->the_post(); ?>

            <?php global $post;?>

            <div class="carousel-item <?php if ( $conter == 1)  echo"active";?> align-items-center"  style="background-image: url('<?php the_post_thumbnail_url(); ?>'); background-repeat: no-repeat; background-size: cover; height:620px;">
              <div class="carouselHeader">
                <?php the_content(); ?>
              </div>
            </div>

            <?php $conter ++; endwhile; endif; ?>
            <?php wp_reset_query();?>

          <!-- <div class="carousel-item align-items-center"  style="background-image: url('http://localhost/din/wp-content/uploads/2021/09/banner-header.png'); background-repeat: no-repeat; background-size: cover; height:500px;">
            <div class="text-center headerContent">
              <h3 class="header">Food app</h3>
              <h2 class="header">Why stay hungry when you can order form Bella Onojie</h2>
              <h4 class="header">Download the bella onoje’s food app now on</h4>
              <div class="header">
                <button class="headerA btn">Playstore</button>
                <button class="headerB btn">App store</button>
              </div>
            </div>
          </div> -->

        </div>
        <a class="carousel-control-prev" href="#carouselExampleControlsHeader" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControlsHeader" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col text-center">
      <img class="img-fluid celsheader" src="http://localhost/din/wp-content/uploads/2021/09/celss.png" alt="">
    <div class="col">
        <div class="row flex-column-reverse">
            <div class="col-12">
              <h1 class="text-center pt-3">How the app works</h1></div>
            </div>
            <div class="col-12">
              <hr>
            </div>
        </div>
    </div>
  </div>
</div>

<div class="container">

    <?php $cont = 1; if(have_posts()) : while(have_posts()) : the_post(); ?>

        <div class="row <?php if ( $cont % 2==1)  echo"flex-row-reverse";?>">
            <div class="col-lg-6 col-sm-12 d-flex align-items-center">
                <div>
                    <h3><a href="<?php the_permalink(); ?>"><?php echo get_post_meta($post->ID, 'subtitle', true); ?></a></h3>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <h4><a href="<?php the_permalink(); ?>"><?php the_excerpt(); ?></a></h4>
                </div>
            </div>
            <div class="col-lg-6 col-sm-12">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('post-thumbnail', array('class' => 'img-fluid text-center')); ?>
                </a>
            </div>
        </div>

    <?php $cont ++; endwhile; else: get_404_template();?>
    <?php endif; ?>
        <div class="blog-pagination mb-5">
            <?php next_posts_link( 'Mais antigos' ); ?> <?php previous_posts_link( 'Mais novos' ); ?>

        </div>
</div>

<div class="container-fluid p-0 ">
  <div class="row mb-4 ">
    <div class="col ">
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner ">
          <?php
            $postType = 'bannerfooter';
            $args = array(
                'post_type'   => $postType,
                'posts_per_page'=> 9,
                'order' => 'ASC',
                // 'taxonomy'=>'category'
                
            );
            $query = new WP_Query( $args );
            ?>

            <?php $conter = 1; if($query->have_posts()) : while($query->have_posts()) : $query->the_post(); ?>

            <?php global $post;?>

            <div class="carousel-item <?php if ( $conter == 1)  echo"active";?> align-items-center"  style="background-image: url('<?php the_post_thumbnail_url(); ?>'); background-repeat: no-repeat; background-size: cover; height:500px;">
              <div class="carouselFooter">
                <?php the_content(); ?>
              </div>
            </div>

            <?php $conter ++; endwhile; endif; ?>
            <?php wp_reset_query();?>

          <!-- <div class="carousel-item active align-items-center"  style="background-image: url('http://localhost/din/wp-content/uploads/2021/09/banner-footer.png'); background-repeat: no-repeat; background-size: cover; height:500px;">
            <div class="text-center footerContent">
              <h2 class="footer">Download the app now.</h2>
              <h4 class="footer">Available on your favorite store. Start your premium experience now</h4>
              <div class="footer">
                <button class="footerA">Playstore</button>
                <button class="footerB">App store</button>
              </div>
            </div>
          </div> -->
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
  </div>
</div>

<?php get_footer(); ?>