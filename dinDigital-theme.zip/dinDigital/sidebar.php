<!-- barra lateral -->

<div class="col-md-4 col-sm-12">

  <?php dynamic_sidebar('Barra lateral');  ?>
      
</div>