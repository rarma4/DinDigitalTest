<!-- Pagina 404 -->
<?php get_header(); ?>

<div class="container">
  <div class="row mt-5">

    <div class="col-md-6 col-sm-12">

        <!-------------Inicio img personalizada--------------->
        <?php 
            $logo404 = get_theme_mod( 'img404' );
            if ($logo404 )
              echo '<img src="'.$logo404.'" alt = "logo alt test" class="img-fluid mb-4 rounded">';
        ?>
        <!-------------fim img personalizada--------------->

    </div>

    <div class="col-md-6 col-sm-12">

    <!-- <h3 class="mb-3">Página não encontrada</h3> -->
    <h5 class="mb-3 row d-flex justify-content-center" ><?php echo get_theme_mod('404_title', 'Página não encontrada'); ?></h5>

    <p><?php echo get_theme_mod('404_text', 'O caminho para o conteúdo que você deseja acessar está errado ou a página pode ter sido excluída.'); ?></p>

    <?php

    echo "<p>Esperimente realizar uma busca para encontrar o conteúdo que deseja.</p>";
    get_search_form();  

    ?>

    </div>

  </div>

</div>


<?php get_footer(); ?>